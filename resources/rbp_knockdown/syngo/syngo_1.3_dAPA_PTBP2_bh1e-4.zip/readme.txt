SynGO data downloaded on 2026-10-04_11-49 @ https://www.syngoportal.org
SynGO dataset version/release: 1.3

Summary of your gene list
dAPA_PTBP2_BH04
62 / 398 genes from your gene list were mapped to 62 unique SynGO annotated genes.
60 genes have a Cellular Component annotation, 45 for Biological Processes. Note: a gene may have multiple annotations.
2 Cellular Component terms are significantly enriched at 1% FDR, 5 for Biological Processes (testing terms with at least 3 matching input genes).
"brain expressed genes" was selected as the background set. It contains 18372 unique genes in total of which 1776 overlap with SynGO annotated genes (i.e. after complementing the background set with all genes in your gene list / foreground).

"user_genelist_map_to_syngo_genes.xlsx" contains your input genelist (first column) together with the matching gene ID available in SynGO. If your input could not be matched to any SynGO annotated gene, the latter will be empty.
"syngo_annotations_matching_user_input.xlsx" contains all available SynGO annotations that match your input genelist.
"syngo_ontologies_with_annotations_matching_user_input.xlsx" contains all SynGO ontology terms, together with the Gene Set Enrichment Analysis (GSEA) results and all genes from these terms that match your input genelist.
