SynGO data downloaded on 2026-10-04_11-47 @ https://www.syngoportal.org
SynGO dataset version/release: 1.3

Summary of your gene list
dAPA_PCBP2_BH04
4 / 25 genes from your gene list were mapped to 4 unique SynGO annotated genes.
4 genes have a Cellular Component annotation, 2 for Biological Processes. Note: a gene may have multiple annotations.
0 Cellular Component terms are significantly enriched at 1% FDR, 0 for Biological Processes (testing terms with at least 3 matching input genes).
"brain expressed genes" was selected as the background set. It contains 18056 unique genes in total of which 1775 overlap with SynGO annotated genes (i.e. after complementing the background set with all genes in your gene list / foreground).

"user_genelist_map_to_syngo_genes.xlsx" contains your input genelist (first column) together with the matching gene ID available in SynGO. If your input could not be matched to any SynGO annotated gene, the latter will be empty.
"syngo_annotations_matching_user_input.xlsx" contains all available SynGO annotations that match your input genelist.
"syngo_ontologies_with_annotations_matching_user_input.xlsx" contains all SynGO ontology terms, together with the Gene Set Enrichment Analysis (GSEA) results and all genes from these terms that match your input genelist.
